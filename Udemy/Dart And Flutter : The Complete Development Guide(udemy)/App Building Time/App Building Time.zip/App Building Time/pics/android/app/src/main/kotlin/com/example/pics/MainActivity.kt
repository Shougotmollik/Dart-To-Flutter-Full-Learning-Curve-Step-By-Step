package com.example.pics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
